#include "internal.h"
#include "tools/edit_journal.h"
#include <assert.h>
#ifndef _WIN32
#include <signal.h>
#endif
/* Do not compile out assertions in Release builds. */
#ifdef NDEBUG
#undef NDEBUG
#include <assert.h>
#endif
static size_t count(const char *s, void *u) {
    (void)u;
    return strlen(s);
}
static bool cancel_diff(void *user) {
    size_t *calls = user;
    return ++*calls >= 2;
}
static void test_edit_diffs(void) {
    const struct {
        const char *before, *after, *body;
        bool exists;
    } cases[] = {
        {"old\r\n", "new\r\n", "@@ -1,1 +1,1 @@\n-old\r\n+new\r\n", true},
        {"old", "new",
         "@@ -1,1 +1,1 @@\n-old\n\\ No newline at end of file\n"
         "+new\n\\ No newline at end of file\n",
         true},
        {"old\n", "", "@@ -1,1 +0,0 @@\n-old\n", true},
        {"", "new\n", "@@ -0,0 +1,1 @@\n+new\n", true},
        {"", "new\n", "@@ -0,0 +1,1 @@\n+new\n", false},
        {"", "", "new file mode 100644\n", false},
        {"\xc2\xb5\n", "\xe9\x9b\xaa\n", "@@ -1,1 +1,1 @@\n-\xc2\xb5\n+\xe9\x9b\xaa\n", true},
    };
    for (size_t i = 0; i < sizeof(cases) / sizeof(*cases); i++) {
        forge_error error = {0};
        size_t length = 0;
        char *diff = fg_edit_diff("dir\\space \xc2\xb5.txt", cases[i].exists,
                                  (forge_slice){cases[i].before, strlen(cases[i].before)},
                                  (forge_slice){cases[i].after, strlen(cases[i].after)}, &length,
                                  NULL, NULL, 0, &error);
        assert(diff && error.code == FORGE_OK && length == strlen(diff));
        assert(
            strstr(diff,
                   "diff --git \"a/dir/space \\302\\265.txt\" \"b/dir/space \\302\\265.txt\"\n") ==
            diff);
        assert(strstr(diff, cases[i].body));
        assert((strstr(diff, "new file mode 100644\n") != NULL) == !cases[i].exists);
        if (!cases[i].exists && *cases[i].after)
            assert(strstr(diff, "--- /dev/null\n"));
        free(diff);
    }
    forge_error error = {0};
    size_t length = 10;
    forge_slice old = {"old", 3}, next = {"new", 3};
    assert(!fg_edit_diff("x", true, old, old, &length, NULL, NULL, 0, &error));
    assert(error.code == FORGE_ERR_CONFLICT && length == 0);
    assert(!fg_edit_diff("x", false, old, next, &length, NULL, NULL, 0, &error));
    assert(error.code == FORGE_ERR_ARGUMENT);
    assert(!fg_edit_diff("../x", true, old, next, &length, NULL, NULL, 0, &error));
    assert(error.code == FORGE_ERR_ARGUMENT);
    const forge_slice bad[] = {
        {"a\0b", 3}, {"\xff", 1}, {NULL, 3}, {"x", 16u * 1024u * 1024u + 1u}};
    const forge_status expected[] = {FORGE_ERR_PARSE, FORGE_ERR_PARSE, FORGE_ERR_ARGUMENT,
                                     FORGE_ERR_LIMIT};
    for (size_t i = 0; i < sizeof(bad) / sizeof(*bad); i++) {
        assert(!fg_edit_diff("x", true, bad[i], next, &length, NULL, NULL, 0, &error));
        assert(error.code == expected[i] && length == 0);
        assert(!fg_edit_diff("x", true, old, bad[i], &length, NULL, NULL, 0, &error));
        assert(error.code == expected[i] && length == 0);
    }
    size_t calls = 0;
    assert(!fg_edit_diff("x", true, old, next, &length, cancel_diff, &calls, 0, &error));
    assert(error.code == FORGE_ERR_CANCELLED && calls == 2);
    assert(!fg_edit_diff("x", true, old, next, &length, NULL, NULL, 1, &error));
    assert(error.code == FORGE_ERR_CANCELLED);
}
static void test_utf8_and_byte_rendering(void) {
    const char text[] = "a\xc2\xa2\xe2\x82\xac\xf0\x9f\x8c\x8d"
                        "z";
    const size_t boundaries[] = {0, 1, 3, 6, 10, 11};
    assert(fg_utf8_valid(text, sizeof(text) - 1));
    assert(fg_utf8_valid(NULL, 0));
    assert(!fg_utf8_valid(NULL, 1));
    for (size_t cut = 0; cut <= sizeof(text); cut++) {
        size_t before = 0, after = sizeof(text) - 1;
        for (size_t i = 0; i < sizeof(boundaries) / sizeof(*boundaries); i++) {
            if (boundaries[i] <= cut)
                before = boundaries[i];
            if (boundaries[i] >= cut) {
                after = boundaries[i];
                break;
            }
        }
        size_t prefix = fg_utf8_prefix(text, sizeof(text) - 1, cut);
        size_t forward = fg_utf8_forward(text, sizeof(text) - 1, cut);
        assert(prefix == before && forward == after);
        assert(fg_utf8_valid(text, prefix));
        assert(fg_utf8_valid(text + forward, sizeof(text) - 1 - forward));
    }
    const char *invalid[] = {"\x80",
                             "\xc0\x80",
                             "\xc2",
                             "\xe0\x80\x80",
                             "\xed\xa0\x80",
                             "\xe2\x82",
                             "\xf0\x80\x80\x80",
                             "\xf4\x90\x80\x80",
                             "\xf5\x80\x80\x80",
                             "\xff"};
    for (size_t i = 0; i < sizeof(invalid) / sizeof(*invalid); i++)
        assert(!fg_utf8_valid(invalid[i], strlen(invalid[i])));
    const char limits[] = "\xe0\xa0\x80\xed\x9f\xbf\xf0\x90\x80\x80\xf4\x8f\xbf\xbf";
    assert(fg_utf8_valid(limits, sizeof(limits) - 1));

    const char binary[] = "a\0b\n\t\r\x01\x7f\xff\xed\xa0\x80\xe2\x82\xac"
                          "z";
    const char *expected = "a\\x00b\n\t\r\\x01\\x7f\\xff\\xed\\xa0\\x80\xe2\x82\xac"
                           "z";
    char *rendered = fg_render_bytes(binary, sizeof(binary) - 1);
    assert(rendered && !strcmp(rendered, expected));
    assert(fg_utf8_valid(rendered, strlen(rendered)));
    free(rendered);
    assert(!fg_render_bytes(NULL, 1));
    rendered = fg_render_bytes(NULL, 0);
    assert(rendered && !*rendered);
    free(rendered);

    fg_process_result process = {0};
    process.out = (char *)binary;
    process.out_len = sizeof(binary) - 1;
    process.err = (char *)"\xc2";
    process.err_len = 1;
    rendered = fg_process_render(&process);
    assert(rendered && strstr(rendered, expected) && strstr(rendered, "stderr:\n\\xc2"));
    assert(fg_utf8_valid(rendered, strlen(rendered)));
    free(rendered);
}
static void assert_valid_compression(const char *raw, size_t first_budget, size_t last_budget) {
    for (size_t budget = first_budget; budget <= last_budget; budget++) {
        forge_error error = {0};
        size_t visible = SIZE_MAX;
        char *compressed = fg_compress_output(raw, budget, &visible, &error);
        assert(compressed && error.code == FORGE_OK);
        assert(visible == strlen(compressed) && visible <= budget);
        assert(fg_utf8_valid(compressed, visible));
        free(compressed);
    }
}
static void test_diagnostic_byte_boundaries(void) {
    forge_error error = {0};
    fg_buf line = {0}, raw = {0};
    fg_buf_puts(&line, "x.go:1: error ");
    while (line.len < 1023)
        fg_buf_puts(&line, "a");
    fg_buf_puts(&line, "\xe2\x82\xac"
                       "after clip");
    char *quoted = fg_json_string(line.data);
    assert(quoted);
    fg_buf_printf(&raw, "{\"Action\":\"output\",\"Output\":%s}\n", quoted);
    free(quoted);
    char *compressed = fg_compress_output(raw.data, 2048, NULL, &error);
    assert(compressed && strlen(compressed) == 1024 && compressed[1023] == '\n');
    assert(fg_utf8_valid(compressed, strlen(compressed)));
    assert(!strstr(compressed, "after clip"));
    free(compressed);
    fg_buf_clear(&line);
    fg_buf_clear(&raw);

    /* Exercise generic prefix, tail-start and final boundaries at every byte. */
    fg_buf_puts(&raw, "x.go:1: error ");
    for (size_t i = 0; i < 250; i++)
        fg_buf_puts(&raw, "\xe2\x82\xac");
    fg_buf_puts(&raw, "\nprogress ");
    for (size_t i = 0; i < 700; i++)
        fg_buf_puts(&raw, "\xf0\x9f\x8c\x8d");
    fg_buf_puts(&raw, "\n");
    assert_valid_compression(raw.data, 64, 1536);
    fg_buf_clear(&raw);

    /* No relevant diagnostics: Go's fallback tail must also accept budget<80. */
    fg_buf_puts(&raw, "{\"Action\":\"output\",\"Output\":\"");
    for (size_t i = 0; i < 200; i++)
        fg_buf_puts(&raw, "\xc2\xa2");
    fg_buf_puts(&raw, "\"}\n");
    assert_valid_compression(raw.data, 64, 256);
    fg_buf_clear(&raw);

    /* Long failure identities can reach the final output budget boundary. */
    fg_buf_puts(&raw, "{\"Action\":\"fail\",\"Package\":\"");
    for (size_t i = 0; i < 200; i++)
        fg_buf_puts(&raw, "\xe2\x82\xac");
    fg_buf_puts(&raw, "\"}\n");
    assert_valid_compression(raw.data, 64, 256);
    fg_buf_clear(&raw);

    const char *nul_json = "{\"Action\":\"output\",\"Output\":\"before\\u0000x.go:9: "
                           "error after NUL \\u03a9\\n\"}\n";
    compressed = fg_compress_output(nul_json, 1024, NULL, &error);
    assert(compressed && strstr(compressed, "before\\x00x.go:9: error after NUL \xce\xa9"));
    assert(fg_utf8_valid(compressed, strlen(compressed)));
    free(compressed);
    assert(fg_diagnostic_hash(nul_json) !=
           fg_diagnostic_hash("{\"Action\":\"output\",\"Output\":\"before\\u0000x.go:9: "
                              "error different after NUL \\u03a9\\n\"}\n"));
    compressed = fg_compress_output("error invalid \xff"
                                    " and control \x01"
                                    "after",
                                    256, NULL, &error);
    assert(compressed && strstr(compressed, "\\xff and control \\x01after"));
    assert(fg_utf8_valid(compressed, strlen(compressed)));
    free(compressed);
}

static void test_native_tool_schema_and_normalization(void) {
    char *schema = fg_tool_native_schema();
    assert(schema);
    yyjson_doc *document = yyjson_read(schema, strlen(schema), 0);
    yyjson_val *tools = document ? yyjson_doc_get_root(document) : NULL;
    size_t tool_count = 0;
    fg_tools(&tool_count);
    assert(yyjson_is_arr(tools) && yyjson_arr_size(tools) == tool_count + 2);
    bool final = false, memory = false, hunk_newline = false, hunk_structure = false,
         hunk_hash = false, patch_minimal = false, patch_hash = false;
    size_t index, maximum;
    yyjson_val *tool;
    yyjson_arr_foreach(tools, index, maximum, tool) {
        assert(!strcmp(fg_json_str(tool, "type"), "function"));
        yyjson_val *function = yyjson_obj_get(tool, "function");
        const char *name = fg_json_str(function, "name");
        yyjson_val *parameters = yyjson_obj_get(function, "parameters");
        const char *description = fg_json_str(function, "description");
        assert(name && description && yyjson_is_obj(parameters));
        assert(yyjson_is_false(yyjson_obj_get(parameters, "additionalProperties")));
        final |= !strcmp(name, "final") && strstr(description, "trigger required host validation");
        memory |= !strcmp(name, "memory") && strstr(description, "not a completion action");
        hunk_newline |=
            !strcmp(name, "apply_hunk") && strstr(description, "host preserves that line ending");
        hunk_structure |=
            !strcmp(name, "apply_hunk") && strstr(description, "preserve the selected line count");
        hunk_hash |= !strcmp(name, "apply_hunk") && strstr(description, "updated file_sha256");
        patch_minimal |=
            !strcmp(name, "apply_patch") && strstr(description, "smallest unique differing span");
        patch_hash |= !strcmp(name, "apply_patch") && strstr(description, "updated file_sha256");
    }
    assert(final && memory && hunk_newline && hunk_structure && hunk_hash && patch_minimal &&
           patch_hash);
    yyjson_doc_free(document);
    free(schema);

    schema = fg_tool_native_final_schema();
    assert(schema);
    document = yyjson_read(schema, strlen(schema), 0);
    tools = document ? yyjson_doc_get_root(document) : NULL;
    assert(yyjson_is_arr(tools) && yyjson_arr_size(tools) == 1);
    yyjson_val *only = yyjson_arr_get_first(tools);
    assert(only && !strcmp(fg_json_str(yyjson_obj_get(only, "function"), "name"), "final"));
    yyjson_doc_free(document);
    free(schema);

    const char *message = "{\"role\":\"assistant\",\"content\":\"\","
                          "\"reasoning_content\":\"inspect first\",\"tool_calls\":[{"
                          "\"type\":\"function\",\"function\":{\"name\":\"read_file\","
                          "\"arguments\":\"{\\\"path\\\":\\\"calc.go\\\",\\\"start\\\":1,"
                          "\\\"end\\\":2}\"}}]}";
    forge_error error = {0};
    char *action = NULL;
    assert(fg_native_action_normalize(message, true, &action, &error) == FORGE_OK);
    document = yyjson_read(action, strlen(action), 0);
    yyjson_val *root = document ? yyjson_doc_get_root(document) : NULL;
    assert(root && !strcmp(fg_json_str(root, "thought"), "inspect first") &&
           !strcmp(fg_json_str(root, "tool"), "read_file"));
    yyjson_val *args = yyjson_obj_get(root, "args");
    assert(!strcmp(fg_json_str(args, "path"), "calc.go") &&
           yyjson_get_uint(yyjson_obj_get(args, "start")) == 1 &&
           yyjson_get_uint(yyjson_obj_get(args, "end")) == 2);
    yyjson_doc_free(document);
    free(action);

    action = NULL;
    assert(fg_native_action_normalize(message, false, &action, &error) == FORGE_OK);
    assert(!strstr(action, "thought"));
    free(action);

    fg_buf long_message = {0};
    assert(fg_buf_puts(&long_message, "{\"role\":\"assistant\",\"content\":\"\","
                                      "\"reasoning_content\":\""));
    for (size_t i = 0; i < FG_THOUGHT_MAX_BYTES + 100; i++)
        assert(fg_buf_puts(&long_message, "x"));
    assert(fg_buf_puts(&long_message, "\",\"tool_calls\":[{\"type\":\"function\",\"function\":{"
                                      "\"name\":\"git_status\",\"arguments\":\"{}\"}}]}"));
    action = NULL;
    assert(fg_native_action_normalize(long_message.data, true, &action, &error) == FORGE_OK);
    document = yyjson_read(action, strlen(action), 0);
    root = document ? yyjson_doc_get_root(document) : NULL;
    assert(root && strlen(fg_json_str(root, "thought")) == FG_THOUGHT_MAX_BYTES);
    yyjson_doc_free(document);
    free(action);
    fg_buf_clear(&long_message);

    message = "{\"role\":\"assistant\",\"content\":\"\",\"tool_calls\":[{"
              "\"id\":\"call_1\",\"type\":\"function\",\"function\":{"
              "\"name\":\"final\",\"arguments\":{\"answer\":\"done\"}}}]}";
    action = NULL;
    assert(fg_native_action_normalize(message, true, &action, &error) == FORGE_OK);
    assert(!strcmp(action, "{\"final\":\"done\"}"));
    free(action);

    const char *unsupported = "{\"role\":\"assistant\",\"content\":\"\",\"tool_calls\":[{"
                              "\"type\":\"function\",\"function\":{\"name\":\"delete_everything\","
                              "\"arguments\":\"{}\"}}]}";
    action = NULL;
    assert(fg_native_action_normalize(unsupported, true, &action, &error) == FORGE_ERR_UNSUPPORTED);
    assert(!action && strstr(error.message, "unsupported tool"));
    const char *parallel = "{\"role\":\"assistant\",\"content\":\"\",\"tool_calls\":["
                           "{\"type\":\"function\",\"function\":{\"name\":\"git_status\","
                           "\"arguments\":\"{}\"}},{\"type\":\"function\",\"function\":{"
                           "\"name\":\"git_diff\",\"arguments\":\"{}\"}}]}";
    assert(fg_native_action_normalize(parallel, true, &action, &error) == FORGE_ERR_PARSE);
    assert(!action && strstr(error.message, "exactly one"));
    const char *bad_args = "{\"role\":\"assistant\",\"content\":\"\",\"tool_calls\":[{"
                           "\"type\":\"function\",\"function\":{\"name\":\"read_file\","
                           "\"arguments\":\"{\\\"path\\\":\\\"x\\\",\\\"start\\\":1}\"}}]}";
    assert(fg_native_action_normalize(bad_args, true, &action, &error) == FORGE_ERR_PARSE);
    assert(!action && strstr(error.message, "missing end"));
    const char *nul_name = "{\"role\":\"assistant\",\"content\":\"\",\"tool_calls\":[{"
                           "\"type\":\"function\",\"function\":{\"name\":\"read_file\\u0000junk\","
                           "\"arguments\":\"{}\"}}]}";
    assert(fg_native_action_normalize(nul_name, true, &action, &error) == FORGE_ERR_PARSE);
    assert(!action && strstr(error.message, "requires type=function"));
    const char *extra = "{\"role\":\"assistant\",\"content\":\"\",\"unexpected\":true,"
                        "\"tool_calls\":[{\"type\":\"function\",\"function\":{"
                        "\"name\":\"git_status\",\"arguments\":\"{}\"}}]}";
    assert(fg_native_action_normalize(extra, true, &action, &error) == FORGE_ERR_PARSE);
    assert(!action && strstr(error.message, "malformed fields"));
    const char *missing_content = "{\"role\":\"assistant\",\"unexpected\":true,\"tool_calls\":[{"
                                  "\"type\":\"function\",\"function\":{\"name\":\"git_status\","
                                  "\"arguments\":\"{}\"}}]}";
    assert(fg_native_action_normalize(missing_content, true, &action, &error) == FORGE_ERR_PARSE);
    assert(!action && strstr(error.message, "assistant content"));
    const char *duplicate_role = "{\"role\":\"assistant\",\"role\":\"assistant\",\"tool_calls\":[{"
                                 "\"type\":\"function\",\"function\":{\"name\":\"git_status\","
                                 "\"arguments\":\"{}\"}}]}";
    assert(fg_native_action_normalize(duplicate_role, true, &action, &error) == FORGE_ERR_PARSE);
    assert(!action && strstr(error.message, "assistant content"));
}
int main(void) {
    forge_model_config defaults = forge_default_model_config();
    assert(defaults.prompt_protocol == FORGE_PROMPT_NATIVE);
    test_edit_diffs();
    test_utf8_and_byte_rendering();
    test_diagnostic_byte_boundaries();
    test_native_tool_schema_and_normalization();
    fg_buf b = {0};
    assert(fg_buf_puts(&b, "abc"));
    assert(fg_buf_printf(&b, "%d", 123));
    char *s = fg_buf_take(&b);
    assert(!strcmp(s, "abc123"));
    free(s);
    forge_error e = {0};
    char path[FG_PATH_MAX];
    assert(!fg_safe_path(".", "../secret", true, path, &e));
    assert(e.code == FORGE_ERR_POLICY);
    assert(!fg_safe_path(".", "C:/secret", true, path, &e));
    assert(!fg_safe_path(".", ".git/config", true, path, &e));
    forge_context *c = forge_context_create(300, 50, count, NULL);
    assert(c);
    uint64_t a = forge_context_add(c, FORGE_SEG_SYSTEM, "stable system", 100, true, 0, 0);
    assert(a);
    uint64_t action = forge_context_add(c, FORGE_SEG_ACTION, "read_file", 1, false, 0, 0);
    forge_context_add(c, FORGE_SEG_RESULT, "important result", 90, false, action, 0);
    size_t tokens = 0, evicted = 0;
    s = forge_context_plan(c, &tokens, &evicted, &e);
    assert(s && tokens <= 250);
    assert(strstr(s, "read_file") < strstr(s, "important result"));
    free(s);
    assert(forge_context_update(c, a, "new system", 1) == FORGE_OK);
    s = forge_context_plan(c, &tokens, &evicted, &e);
    assert(s && strstr(s, "new system"));
    free(s);
    forge_context_destroy(c);
    c = forge_context_create(30, 10, count, NULL);
    forge_context_add(c, FORGE_SEG_SYSTEM, "This pinned text cannot possibly fit", 100, true, 0, 0);
    assert(!forge_context_plan(c, NULL, NULL, &e));
    assert(e.code == FORGE_ERR_LIMIT);
    forge_context_destroy(c);
    const char *j = "{\"path\":\"x\",\"start\":1,\"end\":2}";
    yyjson_doc *d = yyjson_read(j, strlen(j), 0);
    assert(d && fg_tool_validate("read_file", yyjson_doc_get_root(d), &e));
    uint64_t signature = fg_tool_signature("read_file", yyjson_doc_get_root(d), 4, 7);
    yyjson_doc_free(d);
    j = "{ \"end\": 2, \"path\": \"x\", \"start\": 1 }";
    d = yyjson_read(j, strlen(j), 0);
    assert(signature == fg_tool_signature("read_file", yyjson_doc_get_root(d), 4, 7));
    assert(signature != fg_tool_signature("read_file", yyjson_doc_get_root(d), 5, 7));
    assert(signature != fg_tool_signature("read_file", yyjson_doc_get_root(d), 4, 8));
    yyjson_doc_free(d);
    j = "{\"path\":\"x\",\"start\":0,\"end\":2}";
    d = yyjson_read(j, strlen(j), 0);
    assert(!fg_tool_validate("read_file", yyjson_doc_get_root(d), &e));
    yyjson_doc_free(d);
    j = "{\"path\":\"x\",\"start\":-1,\"end\":2}";
    d = yyjson_read(j, strlen(j), 0);
    assert(!fg_tool_validate("read_file", yyjson_doc_get_root(d), &e));
    yyjson_doc_free(d);
    s = fg_tool_grammar(true, false, false);
    assert(s && strstr(s, "call0") && strstr(s, "root ::="));
    assert(strstr(s, "thought ::=") && strstr(s, " ws thought? "));
    free(s);
    s = fg_tool_schema(true, false, false);
    assert(s && strstr(s, "\"thought\"") && strstr(s, "2048") && strstr(s, "may begin"));
    free(s);
    /* The §32 ablation control removes the reasoning channel from generation
     * without touching the constrained action: every call rule survives. */
    s = fg_tool_grammar(false, false, false);
    assert(s && strstr(s, "call0") && strstr(s, "root ::="));
    assert(!strstr(s, "thought"));
    free(s);
    s = fg_tool_schema(false, false, false);
    assert(s && !strstr(s, "thought") && strstr(s, "read_file"));
    free(s);
    /* Required mode is the measurable "on" arm: models do not reliably opt
     * into an optional field, so the ablation needs the channel mandatory. */
    s = fg_tool_grammar(true, true, false);
    assert(s && strstr(s, "thought ::=") && strstr(s, " ws thought ") &&
           !strstr(s, " ws thought? "));
    free(s);
    s = fg_tool_schema(true, true, false);
    assert(s && strstr(s, "MUST begin") && !strstr(s, "may begin"));
    free(s);
    /* Requiring the field cannot resurrect a disabled channel. */
    s = fg_tool_grammar(false, true, false);
    assert(s && !strstr(s, "thought"));
    free(s);
    /* Routed mode moves thought before the JSON object and therefore keeps the
     * action grammar free of an inline thought field. */
    s = fg_tool_grammar(true, false, true);
    assert(s && strstr(s, "call0") && !strstr(s, "thought"));
    free(s);
    s = fg_tool_schema(true, false, true);
    assert(s && strstr(s, "Reason in plain text") && strstr(s, "is optional") &&
           strstr(s, "Do not put a thought field"));
    free(s);
    s = fg_tool_schema(true, true, true);
    assert(s && strstr(s, "MUST be nonempty"));
    free(s);
    /* §32 decode-state routing predicates. fg_action_begin mirrors the lazy
     * trigger: an envelope key must open the object, so reasoning prose and
     * embedded non-action objects never mark the constrained region. */
    const char *begun = fg_action_begin("Thought: adding first {\"tool\":\"read_file\"");
    assert(begun && !strncmp(begun, "{\"tool\"", 7));
    begun = fg_action_begin("x { \"final\" : \"done\"}");
    assert(begun && !strncmp(begun, "{ \"final\"", 9));
    assert(!fg_action_begin("no action here"));
    assert(!fg_action_begin("{\"thought\":\"only\"}"));
    assert(!fg_action_begin("{\"x\":1,\"tool\":\"late key\"}"));
    /* Completion requires a full parse to the end of the text: an unclosed
     * object, or a '}' inside a string, must not end generation early. */
    assert(fg_action_complete("{\"tool\":\"list_files\",\"args\":{\"path\":\".\"}}"));
    assert(fg_action_complete("prose then {\"final\":\"done\"} \n"));
    assert(!fg_action_complete("{\"tool\":\"list_files\",\"args\":{\"path\":\".\"}"));
    assert(!fg_action_complete("{\"final\":\"a brace } inside"));
    assert(!fg_action_complete("nothing"));
    assert(fg_json_whitespace_only(" \t\r\n", 4));
    assert(!fg_json_whitespace_only("", 0));
    assert(!fg_json_whitespace_only(" \n{", 3));
    assert(!fg_native_force_due(false, false, 0, 2048));
    assert(!fg_native_force_due(true, false, 0, 0));
    assert(!fg_native_force_due(true, false, 0, 1));
    assert(!fg_native_force_due(true, false, 1, 1));
    assert(!fg_native_force_due(true, false, 1, 0));
    const size_t native_budgets[] = {2, 32, 64, 512, 513, 2048};
    for (size_t i = 0; i < sizeof(native_budgets) / sizeof(*native_budgets); i++) {
        size_t budget = native_budgets[i];
        size_t cap = FG_MIN((size_t)256, budget / 2);
        assert(!fg_native_force_due(true, false, cap - 1, budget));
        assert(fg_native_force_due(true, false, cap, budget));
        assert(!fg_native_force_due(true, true, cap, budget));
        assert(!fg_native_force_due(false, false, cap, budget));
        assert(!fg_native_force_due(true, false, budget, budget));
    }
    assert(fg_action_decode_phase("") == FG_ACTION_SELECT);
    assert(fg_action_decode_phase("{\"tool\":\"read_file\",\"args\":{") == FG_ACTION_ARGUMENTS);
    assert(fg_action_decode_phase("{\"tool\":\"apply_patch\",\"args\":{") == FG_ACTION_PATCH);
    assert(fg_action_decode_phase("{\"thought\":\"use { tool carefully\","
                                  "\"tool\":\"apply_patch\",\"args\":{") == FG_ACTION_PATCH);
    assert(fg_action_decode_phase("{\"thought\":\"the key \\\"tool\\\" is quoted\"") ==
           FG_ACTION_SELECT);
    assert(fg_action_decode_phase("{\"final\":\"") == FG_ACTION_FINAL);
    assert(fg_action_decode_phase("{\"memory\":{") == FG_ACTION_MEMORY);
    /* Think bounds: the suppress window stays a quarter capped at 32; the cap
     * defaults to a measured 256 ceiling (half-turn when smaller); a configured
     * budget clamps the window; the unbounded ablation removes the cap; and an
     * empty cue removes the window (banning the opener without steering text is
     * the measured prompt-echo death configuration). */
    fg_decode_policy policy = {FG_ACTION_TRIGGER_PATTERN, NULL, 0, false, false};
    size_t min_think = 0, think_cap = 0;
    fg_think_bounds(&policy, 2048, &min_think, &think_cap);
    assert(min_think == 32 && think_cap == 256);
    fg_think_bounds(&policy, 64, &min_think, &think_cap);
    assert(min_think == 16 && think_cap == 32);
    policy.think_budget = 8;
    fg_think_bounds(&policy, 2048, &min_think, &think_cap);
    assert(min_think == 8 && think_cap == 8);
    policy.think_budget = 0;
    policy.think_unbounded = true;
    fg_think_bounds(&policy, 2048, &min_think, &think_cap);
    assert(min_think == 32 && think_cap == SIZE_MAX);
    policy.think_unbounded = false;
    policy.cue = "";
    fg_think_bounds(&policy, 2048, &min_think, &think_cap);
    assert(min_think == 0 && think_cap == 256);
    policy.native_thinking = true;
    fg_think_bounds(&policy, 2048, &min_think, &think_cap);
    assert(min_think == 0 && think_cap == SIZE_MAX);
    /* A budget-forced action can cut the reasoning mid-character; only a
     * trailing incomplete sequence is dropped, and invalid bytes elsewhere
     * stay for validation to reject. */
    assert(fg_utf8_trim_incomplete("abc", 3) == 3);
    assert(fg_utf8_trim_incomplete("ab\xf0", 3) == 2);
    assert(fg_utf8_trim_incomplete("ab\xf0\x9f", 4) == 2);
    assert(fg_utf8_trim_incomplete("ab\xc3\xa9", 4) == 4);
    assert(fg_utf8_trim_incomplete("ab\xc0", 3) == 3);
    assert(fg_utf8_trim_incomplete("ab\xf5", 3) == 3);
    assert(fg_utf8_trim_incomplete("\x80\x80", 2) == 2);
    assert(fg_utf8_trim_incomplete("", 0) == 0);
    const char *raw =
        "{\"Action\":\"pass\",\"Test\":\"TestOK\"}\n{\"Action\":\"fail\",\"Package\":\"example/"
        "math\",\"Test\":\"TestAdd\"}\n{\"Action\":\"output\",\"Output\":\"math_test.go:9: "
        "expected 4 got 3\\n\"}\n";
    const char *later =
        "{\"Time\":\"later\",\"Action\":\"output\",\"Output\":\"math_test.go:9: "
        "expected 4 got 3\\n\"}\n{\"Time\":\"later\",\"Elapsed\":42,\"Action\":\"fail\","
        "\"Test\":\"TestAdd\",\"Package\":\"example/math\"}\n";
    assert(fg_diagnostic_hash(raw) == fg_diagnostic_hash(later));
    assert(fg_diagnostic_hash(raw) != fg_diagnostic_hash("math_test.go:9: expected 5 got 3\n"));
    s = fg_compress_output(raw, 1024, NULL, &e);
    assert(s && strstr(s, "TestAdd") && strstr(s, "expected 4") && strstr(s, "pass=1"));
    free(s);
    raw = "exit_code=0\n{\"answer\":42}\nordinary stdout\n";
    s = fg_compress_output(raw, 256, NULL, &e);
    assert(s && !strcmp(s, raw));
    free(s);
    fg_buf_puts(&b, "exit_code=0\n");
    for (size_t i = 0; i < 100; i++)
        fg_buf_puts(&b, "verbose progress\n");
    fg_buf_puts(&b, "result at end\n");
    s = fg_compress_output(b.data, 256, NULL, &e);
    assert(s && strlen(s) <= 256 && strstr(s, "result at end"));
    free(s);
    fg_buf_clear(&b);
#ifndef _WIN32
    void (*old_handler)(int) = signal(SIGCHLD, SIG_IGN);
    const char *command[] = {"/bin/sh", "-c", "exit 0", NULL};
    fg_process_result result = {0};
    assert(fg_process(".", command, 1000, 4096, NULL, NULL, &result, &e) == FORGE_OK);
    signal(SIGCHLD, old_handler);
    assert(result.exit_code == -1);
    fg_process_free(&result);
#endif
    puts("core tests passed");
    return 0;
}
