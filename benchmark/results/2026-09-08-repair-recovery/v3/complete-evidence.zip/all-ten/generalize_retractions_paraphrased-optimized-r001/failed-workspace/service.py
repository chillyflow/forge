def balances(events):
    seen, cancelled = set(), set()
    postings, totals = {}, {}
    for event in events:
        if event['id'] in seen:
            continue
        seen.add(event['id'])
        if event['kind'] == 'post':
            account, amount = event['account'], event['amount']
            # If this posting was already cancelled, skip it
            if event['id'] in cancelled:
                continue
            postings[event['id']] = (account, amount)
            totals.setdefault(account, 0)
            totals[account] += amount
        else:
            target = event['target']
            # Mark the target as cancelled
            cancelled.add(target)
            # If the target posting exists, remove it from totals
            if target in postings:
                account, amount = postings[target]
                totals[account] -= amount
                # Remove the posting from postings dict to ensure it's not counted again
                del postings[target]
    return totals
